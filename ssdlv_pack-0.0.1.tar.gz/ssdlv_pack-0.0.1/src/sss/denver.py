import pytesseract as ocr

def run_ocr(filename):
    return ocr.image_to_string(filename)